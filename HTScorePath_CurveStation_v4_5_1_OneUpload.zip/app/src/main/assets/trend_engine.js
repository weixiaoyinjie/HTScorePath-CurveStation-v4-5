/* HT Curve v4: deterministic chart calculations, no network access, no odds estimates. */
(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.HTTrend=api;})(typeof globalThis==='object'?globalThis:this,function(){
'use strict';
const METRICS={
 xg:{label:'xG',unit:'',cumulative:true},shots:{label:'总射门',unit:'次',cumulative:true},
 on:{label:'射正',unit:'次',cumulative:true},box:{label:'禁区内射门',unit:'次',cumulative:true},
 off:{label:'射偏',unit:'次',cumulative:true},blocked:{label:'封堵射门',unit:'次',cumulative:true},
 danger:{label:'危险进攻',unit:'次',cumulative:true},corners:{label:'角球',unit:'次',cumulative:true},
 offsides:{label:'越位',unit:'次',cumulative:true},
 pos:{label:'控球率',unit:'%',cumulative:false},
 attacks:{label:'进攻次数',unit:'次',cumulative:true},
 keyPasses:{label:'关键传球',unit:'次',cumulative:true},
 crosses:{label:'传中',unit:'次',cumulative:true},
 saves:{label:'门将扑救',unit:'次',cumulative:true},
 passes:{label:'总传球',unit:'次',cumulative:true},
 accuratePasses:{label:'成功传球',unit:'次',cumulative:true},
 passPct:{label:'传球成功率',unit:'%',cumulative:false},
 momentum:{label:'复合攻势动量（研究指数）',unit:'指数',cumulative:false}
};
function num(v){if(v===null||v===undefined||v===''||typeof v==='boolean')return null;const n=Number(v);return Number.isFinite(n)&&n>=0?n:null;}
function rowsOf(root){return (Array.isArray(root?.samples)?root.samples:[]).filter(r=>r&&Number.isFinite(Number(r.at))&&Number(r.at)>0).slice().sort((a,b)=>a.at-b.at);}
function value(r,side,metric){if(!METRICS[metric]||!r||!r.statsAt||!r[side]||typeof r[side]!=='object')return null;return num(r[side][metric]);}
function baseline(rows,i,side,metric,window){
 if(!METRICS[metric]?.cumulative||!Number.isFinite(window)||window<=0)return null;
 const end=rows[i];if(!end||value(end,side,metric)==null)return null;
 const target=end.at-window*60000,lower=window*60000*.72,upper=window*60000*1.36+25000;
 let selected=null,best=Infinity;
 for(let j=i-1;j>=0;j--){const prev=rows[j];if(prev.phase!==end.phase)continue;
  const elapsed=end.at-prev.at;if(elapsed>upper)break;
  if(elapsed<lower||value(prev,side,metric)==null)continue;
  const d=Math.abs(prev.at-target);
  if(d<best){selected=prev;best=d;}
 }
 return selected;
}
function delta(rows,i,side,metric,window){
 const base=baseline(rows,i,side,metric,window);
 if(!base)return null;
 const a=value(rows[i],side,metric),b=value(base,side,metric);
 if(a===null||b===null||a+1e-8<b)return null; // never turn a reset into an attack
 return Math.round((a-b)*1000)/1000;
}
/** An unvalidated, descriptive market-style pressure oscillator, NOT goal probability.
 * Uses only observed same-phase rolling deltas; never substitutes 0 for missing.
 * The denominators are display scale heuristics, not fitted predictive weights. */
const MOMENTUM_COMPONENTS=[
 ['xg',0.30,0.20],['on',0.24,1.0],['box',0.18,2.0],
 ['shots',0.12,3.0],['danger',0.10,7.0],['attacks',0.06,15.0]
];
function momentumAt(rows,i,side,window=5){
 let n=0,weight=0,quality=0;
 for(const [key,w,base] of MOMENTUM_COMPONENTS){
  const d=delta(rows,i,side,key,window);
  if(d===null)continue;
  // Scale reference with window; cap outliers so one source cannot dominate.
  n+=Math.min(d/(base*window/5),2.5)*w;weight+=w;quality++;
 }
 if(quality<2 || weight<0.20)return null;
 return Math.round(Math.max(0,Math.min(100,n/weight*40))*10)/10;
}
function momentumCoverage(root,window=5){
 const rows=rowsOf(root),i=latestIdx(rows);
 if(i<0)return null;
 const count=side=>MOMENTUM_COMPONENTS.filter(([key])=>delta(rows,i,side,key,window)!==null).length;
 return {home:count('home'),away:count('away'),total:MOMENTUM_COMPONENTS.length};
}
function latestIdx(rows){for(let i=rows.length-1;i>=0;i--){if(rows[i].statsAt&&rows[i].home&&rows[i].away)return i;}return -1;}
function signal(root,window=5){
 const rows=rowsOf(root),i=latestIdx(rows);
 if(i<0)return {quality:'无统计快照',metrics:[],coverage:0,home:0,away:0,ties:0,missing:4,trend:'数据不足'};
 const list=['xg','on','box','shots'].map(key=>{
  const h=delta(rows,i,'home',key,window),a=delta(rows,i,'away',key,window);
  return {key,label:METRICS[key].label,home:h,away:a,leader:h==null||a==null?'missing':h>a?'home':a>h?'away':'tie'};
 });
 const coverage=list.filter(x=>x.leader!=='missing').length;
 const home=list.filter(x=>x.leader==='home').length,away=list.filter(x=>x.leader==='away').length,ties=list.filter(x=>x.leader==='tie').length;
 let trend='数据不足';
 if(coverage>=2){trend=home>=2&&home>away?'主队新增机会较多':away>=2&&away>home?'客队新增机会较多':home===away?'攻势无明显倾向':'信号不一致';}
 const current=rows[i],ageMs=Date.now()-Number(current.statsAt);
 return {metrics:list,coverage,home,away,ties,missing:4-coverage,trend,
  quality:ageMs>180000?'最后快照较旧':coverage>=3?'可比较':'部分指标缺失',
  minute:current.minute,latestAt:current.at,score:`${current.scoreHome}-${current.scoreAway}`};
}
function buildLines(root,metric='xg',mode='cum',window=5,secondary='on'){
 const rows=rowsOf(root),key=METRICS[metric]?metric:'xg',second=METRICS[secondary]?secondary:'on';
 const used=rows.map((r,i)=>({minute:num(r.minute)??0,at:r.at,phase:r.phase??0,
  event:r.goalEvent?'进球/比分变化':r.redEvent?'红牌变化':'',
  score:`${r.scoreHome??'?'}-${r.scoreAway??'?'}`,
  home:key==='momentum'?momentumAt(rows,i,'home',window):mode==='velocity'?delta(rows,i,'home',key,window):value(r,'home',key),
  away:key==='momentum'?momentumAt(rows,i,'away',window):mode==='velocity'?delta(rows,i,'away',key,window):value(r,'away',key),
  home2:value(r,'home',second),away2:value(r,'away',second),
  primary:key,secondary:second}));
 if(mode==='overlay'){
  // Each metric is normalized against the max for BOTH sides of that metric.
  // Never normalize every team's history by its own max (misleading equality).
  const peaks=[Math.max(0,...used.flatMap(x=>[x.home,x.away].filter(Number.isFinite))),
               Math.max(0,...used.flatMap(x=>[x.home2,x.away2].filter(Number.isFinite)))];
  for(const r of used){for(const field of ['home','away'])r[field]=r[field]===null||!peaks[0]?null:Math.round(r[field]/peaks[0]*1000)/10;
   for(const field of ['home2','away2'])r[field]=r[field]===null||!peaks[1]?null:Math.round(r[field]/peaks[1]*1000)/10;
  }
 }
 return used;
}
/** Crosses of SAME-METRIC home/away series; skip gaps, missing data, stale or phase-changed intervals. */
function crossovers(points,gapMs=185000){
 if(!Array.isArray(points))return [];
 const result=[];
 for(let i=1;i<points.length;i++){
  const prev=points[i-1],cur=points[i];
  if(!prev||!cur||prev.phase!==cur.phase||!Number.isFinite(cur.at-prev.at)||cur.at<=prev.at||cur.at-prev.at>gapMs)continue;
  if(![prev.home,prev.away,cur.home,cur.away].every(Number.isFinite))continue;
  const first=prev.home-prev.away,last=cur.home-cur.away;
  // Simply touching zero, or two identical zero series, is not evidence of a takeover.
  if(!(first*last<0))continue;
  const fraction=first/(first-last);
  const minute=Number(prev.minute)+(Number(cur.minute)-Number(prev.minute))*fraction;
  const val=prev.home+(cur.home-prev.home)*fraction;
  result.push({minute:Math.round(minute*10)/10,value:val,phase:cur.phase,direction:last>0?'主队反超':'客队反超',sourceMinute:Number(cur.minute),index:i});
 }
 return result;
}
function recentWindow(root,metric,window){const rows=rowsOf(root),i=latestIdx(rows);if(i<0)return null;
 const h=delta(rows,i,'home',metric,window),a=delta(rows,i,'away',metric,window);
 if(h===null||a===null)return null;return {home:h,away:a,minute:rows[i].minute,sourceAt:rows[i].statsAt};
}
function acceleration(root,metric='xg',window=5){
 const rows=rowsOf(root),i=latestIdx(rows);if(i<0)return null;
 const end=rows[i];let res={};
 for(const side of ['home','away']){
  const now=delta(rows,i,side,metric,window),priorBase=baseline(rows,i,side,metric,2*window),middle=baseline(rows,i,side,metric,window);
  if(now===null||!priorBase||!middle){res[side]=null;continue;}
  const mid=value(middle,side,metric),early=value(priorBase,side,metric);
  if(mid===null||early===null||mid+1e-8<early){res[side]=null;continue;}
  const prev=mid-early;
  res[side]={recent:now,previous:Math.round(prev*1000)/1000,change:Math.round((now-prev)*1000)/1000,
   direction:now>prev+0.0001?'增强':now<prev-0.0001?'减弱':'持平'};
 }
 if(!res.home&&!res.away)return null;
 return res;
}
return {METRICS,num,rowsOf,value,baseline,delta,signal,buildLines,crossovers,recentWindow,acceleration,momentumAt,momentumCoverage};
});
