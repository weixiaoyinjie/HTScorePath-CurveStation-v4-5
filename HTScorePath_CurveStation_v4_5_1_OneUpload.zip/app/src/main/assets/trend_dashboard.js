/* HT ScorePath Curve Station v4.4. Six compact stacked charts. Original notification engine untouched. */
(function(){'use strict';
const E=window.HTTrend;if(!E)return;
const el=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const colors={home:'#ff5368',away:'#35d58b',home2:'#ffa8af',away2:'#96efc0',neutral:'#acbdd0'};
let fixtureId='',archive={},demo=false,chosenIndex=-1,aiRequest=0;
const fmt=v=>v===null||!Number.isFinite(Number(v))?'—':(Math.round(Number(v)*100)/100).toString();
const matchName=m=>`${m.homeName||m.home||'主队'} vs ${m.awayName||m.away||'客队'}`;
function makeDemo(){
 // DEMO ONLY: synthetic counters to demonstrate layout; not a real fixture.
 const samples=[],start=Date.now()-34*60000;
 let hs=0,as=0,ho=0,ao=0,hb=0,ab=0,hd=0,ad=0,ha=0,aa=0,hc=0,ac=0,hk=0,ak=0,hcross=0,across=0;
 for(let m=0;m<=32;m++){
  if(m>0){
   if(m%3===0&&m<23){hs++;ho+=m%2;hb++;}
   if(m%8===0){as++;ao+=(m%16===0?1:0);ab++;}
   if(m===29){as++;ao++;ab++;}
   if(m%2===0){hd+=m<=22?4:1;ad+=m<22?1:4;}
   ha+=(m<23?(m%3===0?2:1):m%3===0?1:0);
   aa+=(m<23?(m%3===0?1:0):m%3===0?3:2);
   if([3,4,9,21].includes(m))hc++;
   if([5,7,28,31].includes(m))ac++;
   if([6,12,20,30].includes(m))hk++;
   if([15,24,26,29].includes(m))ak++;
   if(m%4===0)hcross++;
   if(m%5===0)across++;
  }
  const hX=m<=23?m*.03:.69+(m-23)*.003,aX=m<=22?m*.005:.11+(m-22)*.09;
  const phase=m>=24?2:m>=17?1:0;
  samples.push({at:start+m*60000,statsAt:start+m*60000,minute:m,phase,
   scoreHome:m>=17?1:0,scoreAway:0,goalEvent:m===17,redEvent:m===24,
   home:{shots:hs,on:ho,box:hb,danger:hd,attacks:ha,xg:Math.round(hX*100)/100,pos:m<23?55:46,
    corners:hc,keyPasses:hk,crosses:hcross,saves:ao,passes:Math.round(m*10.5),passPct:84,offsides:Math.floor(m/16),accuratePasses:Math.round(m*8.8)},
   away:{shots:as,on:ao,box:ab,danger:ad,attacks:aa,xg:Math.round(aX*100)/100,pos:m<23?45:54,
    corners:ac,keyPasses:ak,crosses:across,saves:ho,passes:Math.round(m*11.2),passPct:92,offsides:Math.floor(m/21),accuratePasses:Math.round(m*10.3)}});
 }
 return {id:'演示数据',homeName:'模拟主队',awayName:'模拟客队',homeTeamId:1,awayTeamId:2,lastAt:Date.now(),samples,quotes:[],
 timeline:[{minute:7,kind:'yellow',teamId:2},{minute:17,kind:'goal',teamId:1},{minute:24,kind:'red',teamId:2}]};
}
function readRoot(){if(demo)return makeDemo();if(!fixtureId||typeof NativeHT==='undefined')return {samples:[],quotes:[]};try{return JSON.parse(NativeHT.curveHistory(fixtureId))}catch(e){return {samples:[],quotes:[]};}}
function restoreFixtureOptions(){
 let list=[];try{if(typeof NativeHT!=='undefined')list=JSON.parse(NativeHT.curveArchive()||'[]')}catch(e){}
 const entries=new Map();
 (typeof watch!=='undefined'?watch:[]).forEach(m=>entries.set(String(m.id),{id:String(m.id),homeName:m.home,awayName:m.away,live:true}));
 list.forEach(m=>{if(!entries.has(String(m.id)))entries.set(String(m.id),m)});
 if(!fixtureId&&entries.size)fixtureId=[...entries.keys()][0];
 const select=el('curveFixture');select.innerHTML='<option value="">选择监控或已归档比赛</option>'+[...entries.values()].map(m=>`<option value="${esc(m.id)}" ${fixtureId===String(m.id)?'selected':''}>${esc(matchName(m))} · ${esc(m.id)}</option>`).join('');
}
function statsCard(label,a,b,accent=''){return `<div class="cv-stat"><small>${esc(label)}</small><b style="color:${accent||'#e9f6fa'}">${esc(a)}</b><em>${esc(b)}</em></div>`;}
function chart(canvas,series,title='指标',format=v=>fmt(v),maxOverride=null){
 const wrap=canvas.parentElement;const mini=canvas.closest('.cv-mini'),compact=!!mini;const w=Math.max(260,Math.floor(wrap.clientWidth-8)),h=mini?(mini.classList.contains('expanded')?203:112):268;
 const scale=Math.min(2,window.devicePixelRatio||1);canvas.width=Math.floor(w*scale);canvas.height=Math.floor(h*scale);canvas.style.width=w+'px';canvas.style.height=h+'px';
 const c=canvas.getContext('2d');if(!c)return;c.setTransform(scale,0,0,scale,0,0);c.clearRect(0,0,w,h);c.fillStyle='#0a1827';c.fillRect(0,0,w,h);
 const pad=compact?{l:31,r:5,t:12,b:23}:{l:43,r:10,t:20,b:34},gw=w-pad.l-pad.r,gh=h-pad.t-pad.b;
 const points=series.points||[], keys=series.keys||[],all=points.flatMap(p=>keys.map(k=>p[k]).filter(v=>typeof v==='number'&&Number.isFinite(v)));
 if(!all.length){c.textAlign='center';c.font='13px system-ui';c.fillStyle='#aec5d5';c.fillText('暂无这一指标的真实时间序列数据',w/2,h/2);return;}
 const high=Math.max(maxOverride??0,all.length?Math.max(...all):0,0.01),yMax=high*1.13;
 const xMax=Math.max(45,Math.min(60,...points.map(p=>p.minute||0)));
 const x=p=>pad.l+Math.max(0,Math.min(xMax,p.minute||0))/xMax*gw,y=n=>pad.t+gh-(n/yMax)*gh;
 c.lineWidth=1;c.font=compact?'9px system-ui':'11px system-ui';c.textAlign='right';
 const ticks=compact?2:4;for(let i=0;i<=ticks;i++){const yy=pad.t+gh*i/ticks;c.strokeStyle='#294052';c.beginPath();c.moveTo(pad.l,yy);c.lineTo(w-pad.r,yy);c.stroke();c.fillStyle='#91aabd';c.fillText(format(yMax*(ticks-i)/ticks),pad.l-5,yy+3);}
 c.textAlign='center';for(let m=0;m<=xMax;m+=compact?15:10){const xx=pad.l+(m/xMax)*gw;c.fillStyle='#8da7b8';c.fillText(m+'′',xx,h-(compact?6:10));}
 for(const p of points){if(!p.event)continue;c.save();c.setLineDash([3,4]);c.strokeStyle=p.event.includes('红牌')?'#e55e65':'#ffcf6b';c.beginPath();c.moveTo(x(p),pad.t);c.lineTo(x(p),pad.t+gh);c.stroke();c.restore();c.fillStyle='#f9d19f';c.fillText(p.event.includes('红牌')?'R':'G',x(p),compact?9:12);}
 for(const key of keys){c.lineWidth=key.endsWith('2')?1.7:(compact?1.9:2.5);c.strokeStyle=colors[key]||'#fff';c.lineJoin='round';c.setLineDash(key.endsWith('2')?[6,4]:[]);
  c.beginPath();let inPath=false;let last=null;
  for(const p of points){const v=p[key];if(typeof v!=='number'||!Number.isFinite(v)){if(!series.allowSparse)inPath=false;continue;}
   if(last && !series.allowSparse && (p.phase!==last.phase || p.at-last.at>185000)){inPath=false;}
   if(!inPath)c.moveTo(x(p),y(v));else c.lineTo(x(p),y(v));inPath=true;last=p;
  }c.stroke();c.setLineDash([]);
 }
 if(series.showCrosses){
  const crossings=E.crossovers(points);
  for(const q of crossings.slice(-8)){
   const xx=pad.l+Math.max(0,Math.min(xMax,q.minute))/xMax*gw, yy=y(q.value);
   c.save();c.strokeStyle='#cedbeb';c.lineWidth=1;c.setLineDash([2,4]);c.beginPath();c.moveTo(xx,pad.t);c.lineTo(xx,pad.t+gh);c.stroke();c.setLineDash([]);
   c.fillStyle='#d7eaff';c.beginPath();c.arc(xx,yy,4.1,0,Math.PI*2);c.fill();
   c.fillStyle='#cfdfed';c.font=compact?'9px system-ui':'10px system-ui';c.textAlign='center';if(!compact||mini.classList.contains('expanded'))c.fillText('交叉',xx,Math.max(pad.t+12,yy-12));c.restore();
  }
 }
 if(chosenIndex>=0&&points[chosenIndex]){const p=points[chosenIndex];const xx=x(p);c.strokeStyle='#c6e3f3';c.lineWidth=1;c.setLineDash([3,3]);c.beginPath();c.moveTo(xx,pad.t);c.lineTo(xx,pad.t+gh);c.stroke();c.setLineDash([]);
  c.textAlign=xx>w*.58?'right':'left';c.fillStyle='#f0faff';const text=`${p.minute}′ ${p.score||''}  `+keys.map(k=>`${series.labels?.[k]||k}:${format(p[k])}`).join(' · ');
  c.font=compact?'9px system-ui':'11px system-ui';c.fillText(compact&&!mini.classList.contains('expanded')?`${p.minute}′`:text,xx>w*.58?Math.min(w-pad.r,xx-5):Math.max(pad.l,xx+5),pad.t+16);
 }
 canvas.onpointerdown=e=>{if(!points.length)return;const rect=canvas.getBoundingClientRect(),xx=(e.clientX-rect.left)/rect.width*w;let i=0,d=Infinity;
  for(let j=0;j<points.length;j++){const z=Math.abs(x(points[j])-xx);if(z<d){d=z;i=j;}}
  chosenIndex=i;render();};
}
function chartQuotes(root){const canvas=el('priceCanvas'),quotes=(root.quotes||[]).filter(q=>q&&Number.isFinite(q.at)).slice().sort((a,b)=>a.at-b.at);
 const field=el('priceMetric').value;
 const tickets=[...new Set(quotes.map(q=>q.role||'主单'))];
 const displayed=tickets.slice(0,3).map((role,i)=>({role,key:['home','away','home2'][i]}));
 const start=(root.samples||[])[0]?.at||quotes[0]?.at||Date.now();
 const points=quotes.map(q=>({minute:Number(q.minute)||Math.max(0,Math.round((q.at-start)/60000)),at:q.at,
  ...Object.fromEntries(displayed.map(r=>[r.key,r.role===(q.role||'主单')&&q[field]!==null&&q[field]!==undefined?Number(q[field]):null]))}));
 chart(canvas,{points,keys:displayed.map(r=>r.key),labels:Object.fromEntries(displayed.map(r=>[r.key,r.role])),allowSparse:true},'人工价格');
 el('priceLegend').innerHTML=displayed.length?displayed.map(r=>`<span class="cv-leg"><i style="background:${colors[r.key]}"></i>${esc(r.role)}</span>`).join(''):'<span class="minor">尚无人工价格记录；不从投注平台自动抓取赔率或报价</span>';
 el('quoteRows').innerHTML=quotes.slice(-12).reverse().map(q=>`<div class="cv-quote"><span>${esc(q.minute)}′ · ${esc(q.role)} ${esc(q.pick||'')} </span><span>赔率 ${esc(fmt(q.odds))} / 报价 ${esc(fmt(q.cashout))} / 本金 ${esc(fmt(q.stake))}</span></div>`).join('')||'<div class="hint">暂无报价记录。输入后才会有独立价格曲线。</div>';
}
const STACKED=[
 {prefix:'Xg',metric:'xg',mode:'cum'},
 {prefix:'Momentum',metric:'momentum',mode:'cum'},
 {prefix:'XgDelta',metric:'xg',mode:'velocity'},
 {prefix:'OnDelta',metric:'on',mode:'velocity'},
 {prefix:'BoxDelta',metric:'box',mode:'velocity'},
 {prefix:'DangerDelta',metric:'danger',mode:'velocity'},
 {prefix:'AttacksDelta',metric:'attacks',mode:'velocity'},
 {prefix:'ShotsDelta',metric:'shots',mode:'velocity'},
 {prefix:'Shots',metric:'shots',mode:'cum'},
 {prefix:'CornersDelta',metric:'corners',mode:'velocity'},
 {prefix:'KeyPassDelta',metric:'keyPasses',mode:'velocity'},
 {prefix:'Possession',metric:'pos',mode:'cum'},
 {prefix:'PassPct',metric:'passPct',mode:'cum'},
 {prefix:'Saves',metric:'saves',mode:'cum'},
 {prefix:'CrossesDelta',metric:'crosses',mode:'velocity'},
 {prefix:'PassesDelta',metric:'passes',mode:'velocity'}
];
/** Source-event minutes are true match minutes; corners inferred from
 * periodic cumulative stats are ONLY observation minutes, not event times. */
function renderActionAreas(root){
 const rows=E.rowsOf(root),points=[];
 for(const r of rows){
  // Only accept explicitly sourced spatial data. Never derive territories
  // from ball possession or from static screenshot OCR.
  const area=r.actionAreas;
  const source=r.actionAreasSource;
  if(!area||!source||!['provider','event-positions'].includes(source))continue;
  const x=E.num(area.home),m=E.num(area.middle),a=E.num(area.away);
  if(x===null||m===null||a===null||x>100||m>100||a>100||Math.abs(x+m+a-100)>2)continue;
  points.push({at:r.at,minute:r.minute,phase:r.phase,home:x,neutral:m,away:a});
 }
 const last=points[points.length-1];
 el('cvAreaValues').innerHTML=last?`<span class="cv-team-home">主 ${fmt(last.home)}%</span><span>${fmt(last.neutral)}%</span><span class="cv-team-away">客 ${fmt(last.away)}%</span>`:'区域 —';
 chart(el('cvAreaCanvas'),{points,keys:['home','neutral','away'],showCrosses:false},'三区位置占比',v=>fmt(v)+'%',100);
 el('cvAreaInfo').textContent=points.length?`${points.length}组真实位置样本 · 三区占比来自位置数据而非控球率`:
  '未接入带位置标记的事件数据：不根据控球率、射门或截图编造三区占比';
}
/** Horizontal event strip. API fixture event minutes are precise; statistic deltas
 * are only observed at polling minutes and always marked as estimates. */
function renderTimeline(root){
 const target=el('cvTimeline');if(!target)return;
 const events=[];
 const ids={home:Number(root.homeTeamId)||0,away:Number(root.awayTeamId)||0};
 const known={goal:['⚽','进球'],red:['🟥','红牌'],yellow:['🟨','黄牌'],var:['V','VAR'],sub:['⇄','换人']};
 for(const ev of (Array.isArray(root.timeline)?root.timeline:[])){
  const minute=Number(ev?.minute),kind=String(ev?.kind||'');
  if(!Number.isFinite(minute)||minute<0||minute>60||!known[kind])continue;
  const side=ids.home&&Number(ev.teamId)===ids.home?'home':ids.away&&Number(ev.teamId)===ids.away?'away':'unknown';
  events.push({minute,kind,side,icon:known[kind][0],text:known[kind][1],exact:true,detail:typeof ev.detail==='string'?ev.detail:'',source:'足球API事件分钟'});
 }
 const rows=E.rowsOf(root),tracked=[['corners','corner','⚑','角球'],['on','shot','◎','射正'],['offsides','offside','🚩','越位']];
 for(let i=1;i<rows.length;i++){
  const a=rows[i-1],b=rows[i];
  if(a.phase!==b.phase||b.at-a.at>185000||!b.statsAt||!a.statsAt)continue;
  for(const side of ['home','away'])for(const [metric,kind,icon,text] of tracked){
   const from=E.value(a,side,metric),to=E.value(b,side,metric);
   if(from===null||to===null||to<=from)continue;
   const minute=Number(b.minute);
   if(!Number.isFinite(minute)||minute<0||minute>60)continue;
   events.push({minute,kind,side,icon,text:text+' +'+Math.round(to-from),exact:false,detail:'',source:'统计增量首次采样到的分钟，真实发生时间可能更早'});
  }
 }
 events.sort((a,b)=>a.minute-b.minute||(a.exact===b.exact?0:a.exact?-1:1));
 const visible=events.slice(-45),lastMinute=Math.max(45,...rows.map(r=>Number(r.minute)||0),...events.map(e=>e.minute));
 const maxMinute=Math.max(45,Math.min(60,Math.ceil(lastMinute/5)*5));
 const ticks=[];
 for(let t=0;t<=maxMinute;t+=5){const percent=t/maxMinute*100;
  ticks.push(`<span class="cv-tl-gridline" style="left:${percent}%"></span>`);
  if(t%10===0||t===maxMinute)ticks.push(`<span class="cv-tl-time ${t===0?'first':t===maxMinute?'last':''}" style="left:${percent}%">${t}′</span>`);
 }
 // Dense events are grouped into 4-minute bins per side so the touch
 // targets never cover each other on a narrow phone. The details still
 // display the exact minute for every API event in the group.
 const groups=[],byBucket=new Map();
 for(const e of visible){
  const bucket=Math.floor(e.minute/4),key=`${e.side}:${bucket}`;
  let group=byBucket.get(key);
  if(!group){group={side:e.side,bucket,entries:[]};byBucket.set(key,group);groups.push(group);}
  group.entries.push(e);
 }
 groups.sort((a,b)=>a.bucket-b.bucket);
 const priority={goal:0,red:1,yellow:2,var:3,offside:4,shot:5,corner:6,sub:7};
 const pins=groups.map((g,i)=>{
  const selected=g.entries.slice().sort((a,b)=>(priority[a.kind]??9)-(priority[b.kind]??9))[0];
  const center=Math.min(maxMinute, g.bucket*4+2);
  const x=Math.min(98,Math.max(2,center/maxMinute*100));
  const top=g.side==='home'?11:g.side==='away'?52:31;
  const observed=g.entries.every(e=>!e.exact);
  const label=g.entries.length===1?selected.icon:selected.icon+String(g.entries.length);
  return `<button type="button" class="cv-tl-pin ${g.side} ${observed?'observed':'exact'}" data-event-idx="${i}" style="left:${x}%;top:${top}px" aria-label="${esc(g.entries.map(e=>e.minute+'分钟'+e.text).join('，'))}" title="${esc(g.entries.map(e=>e.minute+'′ '+e.text).join('、'))}">${esc(label)}</button>`;
 }).join('');
 const leftLabel=`<span class="cv-team-home">主</span><span class="cv-team-away">客</span>`;
 const board=`<div class="cv-tl-layout"><div class="cv-tl-side-label">${leftLabel}</div><div class="cv-tl-board">${ticks.join('')}<div class="cv-tl-divider"></div>${pins}</div></div>`;
 const quality=E.momentumCoverage(root,Number(el('curveWindow')?.value)||5);
 el('cvTimelineMeta').textContent=`0′—${maxMinute}′ · ${events.length}条`;
 const stamp=visible.length?`${visible[visible.length-1].minute}′ 最新事件：${visible[visible.length-1].text}`:'暂无可验证事件；不代表比赛没有事件';
 const current=target.dataset.selected;
 const makeDetail=g=>g.entries.map(e=>`${e.minute}′ ${e.side==='home'?'主队':e.side==='away'?'客队':'队伍未确认'} ${e.text}${e.detail?' · '+e.detail:''}（${e.exact?'API精确事件时间':'采样发现，非精确时间'}）`).join('；');
 const selected=groups.find((_,i)=>String(i)===current)||groups[groups.length-1];
 target.innerHTML=board+`<div class="cv-tl-detail" id="cvTimelineDetail">${esc(selected?makeDetail(selected):stamp)}</div>`;
 target.querySelectorAll('[data-event-idx]').forEach(btn=>btn.addEventListener('click',()=>{
  target.dataset.selected=btn.dataset.eventIdx;
  target.querySelectorAll('[data-event-idx]').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected');
  const g=groups[Number(btn.dataset.eventIdx)];el('cvTimelineDetail').textContent=makeDetail(g);
 }));
 if(selected){const idx=groups.indexOf(selected);target.querySelector(`[data-event-idx="${idx}"]`)?.classList.add('selected')}
 // Expose incomplete coverage without inventing plot marks.
 const note=quality?`有效动量分量 主${quality.home}/${quality.total} 客${quality.away}/${quality.total}`:'等待同阶段统计';
 target.setAttribute('data-coverage',note);
}
function renderStacked(root,windowM){
 for(const cfg of STACKED){
  const points=E.buildLines(root,cfg.metric,cfg.mode,windowM);
  const last=points.slice().reverse().find(p=>Number.isFinite(p.home)||Number.isFinite(p.away));
  const format=(v)=>fmt(v);
  const valid=points.filter(p=>Number.isFinite(p.home)||Number.isFinite(p.away)).length;
  const title=(cfg.metric==='momentum'?`${windowM}分钟短窗 · `:cfg.mode==='velocity'?`${windowM}分钟新增 · `:'累计 · ')+E.METRICS[cfg.metric].label;
  const labels={home:'主队 '+title,away:'客队 '+title};
  const values=el('cv'+cfg.prefix+'Values');
  values.innerHTML=`<span class="cv-team-home">主 ${esc(fmt(last?.home))}</span><span class="cv-team-away">客 ${esc(fmt(last?.away))}</span>`;
  const canvas=el('cv'+cfg.prefix+'Canvas');
  chart(canvas,{points,keys:['home','away'],labels,showCrosses:true},title,format);
  const crosses=E.crossovers(points);
  let info=valid?`${valid}个有效时间点 · `:'暂无有效时间序列 · ';
  if(crosses.length){const c=crosses[crosses.length-1];info+=`最近交叉 ${fmt(c.minute)}′（${esc(c.direction)}）；交叉不是入场信号`;
  }else{info+='无可验证的主客反超交叉';}
  if(cfg.mode==='velocity')info+=` · 每个点代表此前${windowM}分钟新增`;
  if(cfg.metric==='momentum')info+=` · 研究指数，非进球概率`;
  if(cfg.metric==='pos'||cfg.metric==='passPct')info+=` · 百分比快照，不按累计相减`;
  if(!valid)info+=' · 可能数据缺失或采样时间不足，不能当成0';
  el('cv'+cfg.prefix+'Info').textContent=info;
 }
 renderActionAreas(root);
 renderTimeline(root);
 for(const b of document.querySelectorAll('[data-cvwin]'))b.classList.toggle('active',Number(b.dataset.cvwin)===windowM);
}
function render(){const root=readRoot(),rows=E.rowsOf(root),mode=el('curveMode').value,metric=el('curveMetric').value,windowM=+el('curveWindow').value,second=el('curveSecond').value;
 if(mode==='velocity'&&!E.METRICS[metric].cumulative){el('curveMode').value='cum';return render();}
 el('curveIdentity').textContent=(demo?'【模拟演示 · 非真实比赛】 ':'')+matchName(root)+' · '+(root.id||fixtureId||'无比赛')+' · '+rows.length+' 个快照';
 el('curveLastAt').textContent=rows.length?'最后采样：'+new Date(rows[rows.length-1].at).toLocaleString('zh-CN',{hour12:false}):'等待开始上半场监控：历史不会凭空补齐';
 renderStacked(root,windowM);
 const points=E.buildLines(root,metric,mode,windowM,second);
 const live=(typeof snapshot!=='undefined'?(snapshot?.matches||[]):[]).find(m=>String(m.id)===fixtureId && m.status==='1H');
 if(document.activeElement!==el('quoteMinute') && live && !demo)el('quoteMinute').value=live.minute;
 const keys=mode==='overlay'?['home','away','home2','away2']:['home','away'];
 const labels={home:'主队 '+E.METRICS[metric].label,away:'客队 '+E.METRICS[metric].label,home2:'主队 '+E.METRICS[second].label,away2:'客队 '+E.METRICS[second].label};
 el('cvLegend').innerHTML=keys.map(k=>`<span class="cv-leg"><i style="background:${colors[k]}"></i>${esc(labels[k])}</span>`).join('');
 el('curveSecondWrap').style.display=mode==='overlay'?'block':'none';
 el('cvAxis').textContent=mode==='velocity'?`过去${windowM}分钟新增 · 不是每分钟平均` :mode==='overlay'?'独立指标共同归一化到0–100；不可读成进球概率':`累计数值 · ${E.METRICS[metric].label}${E.METRICS[metric].unit}`;
 chart(el('curveCanvas'),{points,keys,labels,showCrosses:true},'主客曲线',v=>mode==='overlay'?`${Math.round(v)}%`:fmt(v),mode==='overlay'?100:null);
 const crosses=E.crossovers(points);
 const crossLabel=el('cvCrossings');
 crossLabel.textContent=crosses.length?('主客 '+E.METRICS[metric].label+' 曲线交叉：'+crosses.slice(-3).map(c=>c.minute+'′ '+c.direction).join('；')+'。仅表示当前指标相对位置改变，不等于进球或入场信号。'):'同指标曲线暂未发现有效交叉；交叉、斜率和区间增量需要结合比分与样本质量判断。';
 const sig=E.signal(root,windowM),momentum=E.acceleration(root,metric,windowM);
 el('curveQuality').innerHTML=(rows.length?`${(typeof snapshot!=='undefined'&&(snapshot?.matches||[]).some(m=>String(m.id)===fixtureId&&m.status==='1H'))?'实时采样':'历史归档/监控未开始'} · 样本质量：${esc(sig.quality)} · 窗口${windowM}分钟有${sig.coverage}/4种核心指标可比。`:'暂无实际采样；请在开赛时启动原监控。')+
 (demo?' <strong>演示数据不能用于下注</strong>':'')+'<br>缺失数据永不补0；进球/红牌后短窗重新建立，不跨结构突变比较。';
 el('curveStats').innerHTML=statsCard('主队/客队信号数',sig.home+' / '+sig.away,`有效指标 ${sig.coverage}/4`)+
  statsCard(`${windowM}分钟xG变化`,fmt(E.recentWindow(root,'xg',windowM)?.home)+' / '+fmt(E.recentWindow(root,'xg',windowM)?.away),'主队 / 客队')+
  statsCard(`${windowM}分钟射正新增`,fmt(E.recentWindow(root,'on',windowM)?.home)+' / '+fmt(E.recentWindow(root,'on',windowM)?.away),'主队 / 客队')+
  statsCard(`${windowM}分钟禁区射门新增`,fmt(E.recentWindow(root,'box',windowM)?.home)+' / '+fmt(E.recentWindow(root,'box',windowM)?.away),'主队 / 客队');
 el('curveInterpretation').innerHTML=`<b>趋势信号：${esc(sig.trend)}</b><div class="hint">${momentum?.home?`主队${esc(E.METRICS[metric].label)}最近两段：${esc(fmt(momentum.home.previous))} → ${esc(fmt(momentum.home.recent))}（${esc(momentum.home.direction)}）`:'主队最近两段变化：采样不足'}；${momentum?.away?`客队：${esc(fmt(momentum.away.previous))} → ${esc(fmt(momentum.away.recent))}（${esc(momentum.away.direction)}）`:'客队：采样不足'}。</div><small>指标一致性不是胜率、进球概率或下注指令。先看当前比分和剩余时间，结合已设置的比分单判断。</small>`;
 el('cvSignals').innerHTML=sig.metrics.map(m=>`<div class="cv-signal"><span>${esc(m.label)}</span><b>${fmt(m.home)} <span class="muted">/</span> ${fmt(m.away)}</b><small>${m.leader==='home'?'主队较多':m.leader==='away'?'客队较多':m.leader==='tie'?'持平':'缺少有效窗口'}</small></div>`).join('');
 chartQuotes(root); updateQuoteRoles();
}
function updateQuoteRoles(){const sel=el('quoteRole'),existing=sel.value;let names=['主单','保险1','保险2'];const s=sel.options.length?Array.from(sel.options).map(x=>x.value):[];
 if(!s.length){sel.innerHTML=names.map(n=>`<option>${n}</option>`).join('');}sel.value=names.includes(existing)?existing:'主单';
 const rows=(typeof guardBets!=='undefined'&&guardBets[fixtureId])||[];
 const idx=names.indexOf(sel.value);el('quotePick').textContent=rows[idx]?.pick?'目标比分 '+rows[idx].pick:'目标比分未设置';
}
function recordQuote(){if(demo)return alert('模拟演示不能记录真实价格。');if(!fixtureId||typeof NativeHT==='undefined')return alert('请使用 Android App 并选择具体比赛。');
 const role=el('quoteRole').value,odds=el('quoteOdds').value,cashout=el('quoteCashout').value,stake=el('quoteStake').value;
 if(!odds&&!cashout)return alert('至少输入本次真实赔率或实际提前结算报价。');
 const root=readRoot(),last=E.rowsOf(root).slice(-1)[0],bet=((typeof guardBets!=='undefined'&&guardBets[fixtureId])||[])[['主单','保险1','保险2'].indexOf(role)]||{};
 const minuteStr=el('quoteMinute').value.trim();
 if(minuteStr===''||!Number.isInteger(+minuteStr)||+minuteStr<0||+minuteStr>60)return alert('请先确认该报价对应的比赛分钟。');
 const row={role,pick:bet.pick||'',odds:odds===''?null:+odds,cashout:cashout===''?null:+cashout,stake:stake===''?null:+stake,minute:+minuteStr};
 try{const res=JSON.parse(NativeHT.curveQuote(fixtureId,JSON.stringify(row)));if(!res.ok)throw new Error(res.error||'数据校验失败');
  el('quoteOdds').value='';el('quoteCashout').value='';el('quoteSaved').textContent='已记录实际输入的价格：'+new Date().toLocaleTimeString('zh-CN');render();
 }catch(e){alert('价格记录失败：'+e.message);}
}
function redraw(){chosenIndex=-1;render()}
function init(){
 const tab=document.querySelector('[data-tab="curve"]');if(!tab)return;
 tab.addEventListener('click',()=>{restoreFixtureOptions();redraw()});
 const priceTab=document.querySelector('[data-tab="prices"]');
 if(priceTab)priceTab.addEventListener('click',()=>{restoreFixtureOptions();redraw()});
 ['curveMetric','curveMode','curveWindow','curveSecond','priceMetric'].forEach(id=>el(id).addEventListener('change',redraw));
 document.querySelectorAll('[data-cvwin]').forEach(b=>b.addEventListener('click',()=>{el('curveWindow').value=b.dataset.cvwin;redraw();}));
 document.querySelectorAll('#tab-curve .cv-mini').forEach(card=>{
  const head=card.querySelector('.cv-mini-head');if(!head||head.querySelector('.cv-zoom'))return;
  const b=document.createElement('button');b.className='cv-zoom';b.type='button';b.textContent='放大';b.setAttribute('aria-label','放大该指标时间曲线');b.setAttribute('aria-pressed','false');
  head.appendChild(b);b.addEventListener('click',()=>{
   const expanded=card.classList.toggle('expanded');b.textContent=expanded?'收起':'放大';b.setAttribute('aria-pressed',expanded?'true':'false');render();
  });
 });
 el('cvOptionalCharts').addEventListener('toggle',()=>{if(el('cvOptionalCharts').open)render();});
 el('curveFixture').addEventListener('change',()=>{fixtureId=el('curveFixture').value;demo=false;redraw()});
 el('refreshCurve').onclick=()=>{restoreFixtureOptions();redraw()};
 el('curveDemo').onclick=()=>{demo=!demo;el('curveDemo').textContent=demo?'退出模拟演示':'查看模拟演示';redraw()};
 el('quoteRole').addEventListener('change',updateQuoteRoles);el('recordQuote').onclick=recordQuote;
 el('deleteCurve').onclick=()=>{if(demo||!fixtureId)return;if(!confirm('仅删除这场比赛的曲线快照和人工价格记录？原有预警与比分单不受影响。'))return;
  if(NativeHT.curveDelete(fixtureId)){restoreFixtureOptions();redraw();}};
 window.nativeTrendAiDone=(rid,text)=>{
  if(String(rid)!==String(aiRequest))return;
  el('curveAiBtn').disabled=false;el('curveAiBtn').textContent='✦ 重新进行AI曲线复核';
  try{const d=JSON.parse(text);if(d.error)throw new Error(d.error);
   el('curveAiResult').innerHTML=`<b>AI走势复核 · ${esc(d.rating)}</b><br>优势：${esc(d.state)}<br>方向：${esc(d.direction)}<br>证据：${esc(d.evidence)}<br>风险：${esc(d.risk)}<br>结论：${esc(d.action)}<br><small>分析基于有限API采样，不能替代真实赔率核对。</small>`;
  }catch(e){el('curveAiResult').textContent='AI复核不可用：'+e.message;}
 };
 el('curveAiBtn').onclick=()=>{
  if(demo)return alert('模拟曲线不能用于真实AI分析。');
  if(!fixtureId||typeof NativeHT==='undefined')return alert('请在Android App选择有实际曲线的比赛。');
  aiRequest++;el('curveAiBtn').disabled=true;el('curveAiBtn').textContent='AI正在分析已采样曲线…';
  el('curveAiResult').textContent='仅发送比赛统计和事件分段，不发送赔率、注单金额和结算报价。';
  NativeHT.curveAi(fixtureId,String(aiRequest));
 };
 window.refreshTrendHome=()=>{restoreFixtureOptions();if(el('tab-curve').classList.contains('active'))redraw();};
 window.openCurveFor=id=>{fixtureId=String(id);demo=false;if(typeof goto==='function')goto('curve');restoreFixtureOptions();redraw();window.scrollTo({top:0,behavior:'smooth'});};
 window.addEventListener('resize',()=>{if(el('tab-curve').classList.contains('active'))redraw()});
 setInterval(()=>{if(el('tab-curve').classList.contains('active'))render()},12000);
 restoreFixtureOptions();
}
init();
})();
