package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** User-requested chart reading. Not part of alert loop and never sends money/quotes. */
public final class TrendAiReview {
    private TrendAiReview(){}
    public static JSONObject review(JSONObject history,String apiKey)throws Exception{
        if(apiKey==null||apiKey.trim().isEmpty())throw new Exception("请在接口设置中先保存AI Key");
        JSONArray source=history.optJSONArray("samples");
        if(source==null || source.length()<3)throw new Exception("需要至少3个有效曲线快照");
        JSONArray safe=new JSONArray();int valid=0;
        // Include at most 50 samples, preserving the order and event-phase context.
        for(int i=Math.max(0,source.length()-50);i<source.length();i++){
            JSONObject r=source.optJSONObject(i);if(r==null)continue;
            JSONObject compact=new JSONObject().put("minute",r.optInt("minute",0))
                .put("score",r.optInt("scoreHome",0)+"-"+r.optInt("scoreAway",0))
                .put("phase",r.optInt("phase",0))
                .put("goalEvent",r.optBoolean("goalEvent",false))
                .put("redEvent",r.optBoolean("redEvent",false));
            JSONObject h=r.optJSONObject("home"),a=r.optJSONObject("away");
            if(h!=null && a!=null && r.optLong("statsAt",0)>0){
                compact.put("home",cleanStats(h)).put("away",cleanStats(a));valid++;
            }else{compact.put("home",JSONObject.NULL).put("away",JSONObject.NULL);}
            safe.put(compact);
        }
        if(valid<3)throw new Exception("有效统计快照不足3个，无法进行AI走势复核");
        JSONObject request=new JSONObject().put("model","gpt-4.1-mini").put("max_output_tokens",430)
            .put("instructions","你是足球上半场时间曲线复核器。仅阅读给出的真实采样数据，绝对不能使用未提供的事实、赔率或平台结算价。明确区分累积指标与5/10分钟增量，缺失null不可当0，因进球/红牌形成的不同phase不能跨阶段差分。先说明当前谁的真实攻势较强，再说明走势增强/持平/衰减/反转，列出最有价值的两点数值证据及一个最大风险。不能根据此数据预测精确进球时刻或进球概率；数据少或相互冲突时结论PASS/继续观察。这里没有赔率，不能推荐下注或表示存在正期望。必须输出JSON对象，字段state,direction,evidence,risk,rating,action六个简体中文字符串，每个不超过120汉字。rating只可C或PASS；action只能继续观察或核查真实赔率或不参与。")
            .put("input","以下为同场上半场按时间获取的API统计快照，金额、赔率、投注账户信息均不包含："+safe.toString())
            .put("text",new JSONObject().put("format",new JSONObject().put("type","json_object")));
        HttpURLConnection connection=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        try{
            connection.setRequestMethod("POST");connection.setDoOutput(true);
            connection.setConnectTimeout(7500);connection.setReadTimeout(11500);
            connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
            connection.setRequestProperty("Authorization","Bearer "+apiKey);
            try(OutputStream out=connection.getOutputStream()){
                out.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status=connection.getResponseCode();
            if(status<200||status>=300)throw new Exception("AI API HTTP "+status);
            byte[] buf=new byte[4096];int n;ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=connection.getInputStream()){
                while((n=in.read(buf))!=-1){bytes.write(buf,0,n);if(bytes.size()>240_000)throw new Exception("AI响应体过大");}
            }
            JSONArray output=new JSONObject(bytes.toString("UTF-8")).optJSONArray("output");
            String answer="";
            if(output!=null)for(int i=0;i<output.length();i++){
                JSONObject item=output.optJSONObject(i);JSONArray content=item==null?null:item.optJSONArray("content");
                if(content==null)continue;
                for(int j=0;j<content.length();j++){
                    JSONObject block=content.optJSONObject(j);
                    if(block!=null && "output_text".equals(block.optString("type"))){answer=block.optString("text","");break;}
                }
                if(!answer.isEmpty())break;
            }
            JSONObject input=new JSONObject(answer),safeOut=new JSONObject();
            for(String k:new String[]{"state","direction","evidence","risk"})
                safeOut.put(k,trim(input.optString(k,"数据不足"),160));
            String rating=input.optString("rating","PASS");
            safeOut.put("rating","C".equals(rating)?"C":"PASS");
            String action=input.optString("action","继续观察");
            if(!"继续观察".equals(action)&&!"核查真实赔率".equals(action)&&!"不参与".equals(action))action="继续观察";
            safeOut.put("action",action).put("at",System.currentTimeMillis());
            return safeOut;
        }finally{connection.disconnect();}
    }
    private static JSONObject cleanStats(JSONObject src)throws Exception{
        JSONObject out=new JSONObject();
        for(String k:new String[]{"xg","shots","on","box","off","blocked","danger","pos"}){
            Object v=src.opt(k);
            out.put(k,v instanceof Number && Double.isFinite(((Number)v).doubleValue())?v:JSONObject.NULL);
        }
        return out;
    }
    private static String trim(String s,int max){return s.length()>max?s.substring(0,max):s;}
}
