package com.htlive.monitor;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Chart-only first-half samples. Kept SEPARATE from MonitorService's 12-minute
 * alert history: it must not modify alert decisions, risk rules or notifications.
 * Private app files survive HT completion, service recreation and app restart.
 * No network calls or betting account access. Missing stats stay JSON null.
 */
public final class TrendSeriesStore {
    private TrendSeriesStore(){}
    private static final int LIMIT=180;
    private static final long FRESH_MS=100_000L;
    private static final long MIN_SAMPLE_GAP_MS=48_000L;
    private static final String PREFIX="ht_curve4_";
    private static final Object MUTEX=new Object();

    private static String validId(String id){
        return id!=null && id.matches("[0-9]{1,12}")?id:null;
    }
    private static File file(Context ctx,String id){return new File(ctx.getFilesDir(),PREFIX+id+".json");}
    private static JSONObject readObj(File file){
        if(!file.exists())return new JSONObject();
        try(FileInputStream in=new FileInputStream(file)){
            byte[] bytes=new byte[(int)Math.min(file.length(),1024*1024)];
            int offset=0,n;
            while(offset<bytes.length && (n=in.read(bytes,offset,bytes.length-offset))>0)offset+=n;
            return new JSONObject(new String(bytes,0,offset,StandardCharsets.UTF_8));
        }catch(Exception ex){return new JSONObject();}
    }
    private static void atomicWrite(File file,JSONObject data)throws Exception{
        File tmp=new File(file.getParentFile(),file.getName()+".tmp");
        try(FileOutputStream out=new FileOutputStream(tmp)){
            out.write(data.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();out.getFD().sync();
        }
        // Rename on same private filesystem. Do NOT delete last good file first.
        if(!tmp.renameTo(file))throw new Exception("曲线数据保存失败：重命名");
    }
    private static boolean hasStatistic(JSONObject side){
        if(side==null)return false;
        for(String key:new String[]{"xg","shots","on","box","danger","attacks","pos","corners",
                "saves","passes","passPct","keyPasses","crosses","offsides"}){
            Object v=side.opt(key);
            if(v instanceof Number && Double.isFinite(((Number)v).doubleValue()))return true;
        }
        return false;
    }
    public static void append(Context ctx,JSONObject match,boolean scoreChange,boolean redChange){
        if(match==null || !"1H".equals(match.optString("status")))return;
        String id=validId(match.optString("id"));if(id==null)return;
        long now=System.currentTimeMillis(),statsAt=match.optLong("lastStatsAt",0L);
        JSONObject statsObject=match.optJSONObject("stats");
        // The notification engine's stricter stats.available rule is NOT
        // changed; archival curves may use any genuinely present team statistic.
        boolean hasRealStatistic=hasStatistic(statsObject==null?null:statsObject.optJSONObject("home")) ||
            hasStatistic(statsObject==null?null:statsObject.optJSONObject("away"));
        boolean fresh=statsAt>0 && now-statsAt<=FRESH_MS && hasRealStatistic;
        if(!fresh && !scoreChange && !redChange)return;
        synchronized(MUTEX){
            try {
                File file=file(ctx,id);
                JSONObject root=readObj(file);
                JSONArray samples=root.optJSONArray("samples");if(samples==null)samples=new JSONArray();
                JSONObject last=samples.length()>0?samples.optJSONObject(samples.length()-1):null;
                long lastStatsAt=last==null?0L:last.optLong("statsAt",0L);
                // Event-only rows have statsAt=0. Keep a watermark so an old
                // pre-goal cached statistic can never be re-added as new.
                long maxSeenStatsAt=Math.max(root.optLong("maxStatsAt",0L),lastStatsAt);
                long lastAt=last==null?0L:last.optLong("at",0L);
                boolean newStats=fresh && statsAt>maxSeenStatsAt && now-lastAt>=MIN_SAMPLE_GAP_MS;
                // Goals and red cards are event markers even when statistics lag.
                if(!newStats && !scoreChange && !redChange)return;
                JSONObject row=new JSONObject()
                    .put("at",now).put("minute",match.optInt("minute",0))
                    .put("scoreHome",match.optInt("h",0)).put("scoreAway",match.optInt("a",0))
                    .put("goalEvent",scoreChange).put("redEvent",redChange)
                    .put("statsAt",newStats?statsAt:0L)
                    .put("source",newStats?match.optString("statsSource",""):"event-only");
                // An event can occur during statistic throttling. Do NOT attach
                // the previous phase's cached stats to the new phase marker.
                if(newStats){
                    JSONObject stats=match.optJSONObject("stats");
                    row.put("home",new JSONObject(stats.optJSONObject("home").toString()));
                    row.put("away",new JSONObject(stats.optJSONObject("away").toString()));
                }else{row.put("home",JSONObject.NULL).put("away",JSONObject.NULL);}
                // If a score-correction/restart causes minute rewind, preserve as a new phase.
                int phase=last==null?0:last.optInt("phase",0);
                if(last!=null && (scoreChange || redChange ||
                    row.optInt("minute")+2<last.optInt("minute") ||
                    row.optInt("scoreHome")<last.optInt("scoreHome") ||
                    row.optInt("scoreAway")<last.optInt("scoreAway")))phase++;
                row.put("phase",phase);
                samples.put(row);
                JSONArray bounded=new JSONArray();
                for(int i=Math.max(0,samples.length()-LIMIT);i<samples.length();i++)bounded.put(samples.get(i));
                // Actual fixture event minutes (not polling minutes); copied from
                // already retrieved event JSON, never used to trigger alerts.
                JSONArray timeline=match.optJSONArray("chartTimeline");
                if(timeline!=null)root.put("timeline",timeline);
                root.put("id",id).put("homeName",match.optString("home",""))
                    .put("awayName",match.optString("away",""))
                    .put("kickoff",match.optString("kickoff",""))
                    .put("homeTeamId",match.optInt("homeTeamId",0))
                    .put("awayTeamId",match.optInt("awayTeamId",0))
                    .put("league",match.optString("league",""))
                    .put("maxStatsAt",newStats?statsAt:maxSeenStatsAt)
                    .put("lastAt",now).put("samples",bounded);
                atomicWrite(file,root);
            }catch(Exception e){android.util.Log.w("HTCurve4","Chart sample persistence failed",e);}
        }
    }
    /** Only user-entered sportsbook quotes. No sportsbook scraping or auto-trading. */
    public static String addQuote(Context ctx,String fixtureId,String quoteJson){
        String id=validId(fixtureId);
        if(id==null)return "{\"ok\":false,\"error\":\"比赛ID无效\"}";
        synchronized(MUTEX){
            try{
                JSONObject request=new JSONObject(quoteJson);
                String role=request.optString("role","");
                if(!("主单".equals(role)||"保险1".equals(role)||"保险2".equals(role)))
                    throw new IllegalArgumentException("比分单类型无效");
                double odds=numberOrNull(request,"odds"),cashout=numberOrNull(request,"cashout"),stake=numberOrNull(request,"stake");
                if(Double.isNaN(odds)&&Double.isNaN(cashout))
                    throw new IllegalArgumentException("需手动输入真实赔率或结算报价");
                if(!Double.isNaN(odds)&&(odds<1.01||odds>10000))
                    throw new IllegalArgumentException("赔率必须在1.01至10000之间");
                if(!Double.isNaN(cashout)&&(cashout<0||cashout>1e9))
                    throw new IllegalArgumentException("结算报价范围不合法");
                if(!Double.isNaN(stake)&&(stake<0||stake>1e9))
                    throw new IllegalArgumentException("本金范围不合法");
                File file=file(ctx,id);JSONObject root=readObj(file);
                JSONArray quotes=root.optJSONArray("quotes");if(quotes==null)quotes=new JSONArray();
                String pick=request.optString("pick","");
                if(!pick.matches("[0-9]{1,2}-[0-9]{1,2}"))pick="";
                int minute=Math.max(0,Math.min(60,request.optInt("minute",0)));
                JSONObject item=new JSONObject().put("at",System.currentTimeMillis()).put("minute",minute)
                    .put("role",role).put("pick",pick).put("source","manual")
                    .put("odds",Double.isNaN(odds)?JSONObject.NULL:odds)
                    .put("cashout",Double.isNaN(cashout)?JSONObject.NULL:cashout)
                    .put("stake",Double.isNaN(stake)?JSONObject.NULL:stake);
                quotes.put(item);
                JSONArray trimmed=new JSONArray();for(int i=Math.max(0,quotes.length()-240);i<quotes.length();i++)trimmed.put(quotes.get(i));
                root.put("id",id).put("quotes",trimmed);
                atomicWrite(file,root);
                return new JSONObject().put("ok",true).put("count",trimmed.length()).toString();
            }catch(Exception ex){
                try{return new JSONObject().put("ok",false).put("error",String.valueOf(ex.getMessage())).toString();}
                catch(Exception ignored){return "{\"ok\":false}";}
            }
        }
    }
    private static double numberOrNull(JSONObject o,String key){
        if(!o.has(key)||o.isNull(key))return Double.NaN;
        Object value=o.opt(key);if(!(value instanceof Number))return Double.NaN;
        double n=((Number)value).doubleValue();return Double.isFinite(n)?n:Double.NaN;
    }
    public static String get(Context ctx,String fixtureId){
        String id=validId(fixtureId);if(id==null)return "{}";
        synchronized(MUTEX){return readObj(file(ctx,id)).toString();}
    }
    public static String list(Context ctx){
        synchronized(MUTEX){
            JSONArray output=new JSONArray();
            File[] files=ctx.getFilesDir().listFiles((dir,name)->name.matches(PREFIX+"[0-9]{1,12}\\.json"));
            if(files==null)return output.toString();
            ArrayList<JSONObject> items=new ArrayList<>();
            for(File f:files){
                JSONObject root=readObj(f);JSONArray rows=root.optJSONArray("samples");
                if(rows==null||rows.length()==0)continue;
                JSONObject item=new JSONObject();
                try{
                    for(String k:new String[]{"id","homeName","awayName","kickoff","league","lastAt"})
                        item.put(k,root.opt(k));
                    item.put("count",rows.length());items.add(item);
                }catch(Exception ignored){}
            }
            Collections.sort(items,(a,b)->Long.compare(b.optLong("lastAt"),a.optLong("lastAt")));
            for(int i=0;i<Math.min(100,items.size());i++)output.put(items.get(i));
            return output.toString();
        }
    }
    /** Explicit chart-archive deletion only. Never called when HT ends or watchlist prunes. */
    public static boolean delete(Context ctx,String fixtureId){
        String id=validId(fixtureId);if(id==null)return false;
        synchronized(MUTEX){File f=file(ctx,id);return !f.exists()||f.delete();}
    }
}
