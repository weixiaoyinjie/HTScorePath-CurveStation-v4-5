const assert=require('node:assert/strict'),fs=require('node:fs');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const demo=fs.readFileSync('app/src/main/assets/preview_demo.html','utf8');
for(const [kind,s] of [['android',html],['demo',demo]]){
  const pos=id=>s.indexOf('id="'+id+'"');
  for(const id of ['cvTimelineCard','cvStack','cvOptionalCharts','upload','curveNavSlot','curveFixture'])assert(pos(id)>=0,`${kind}: ${id}`);
  assert(pos('cvTimelineCard')<pos('cvStack') && pos('cvStack')<pos('cvOptionalCharts') && pos('cvOptionalCharts')<pos('upload') && pos('upload')<pos('curveNavSlot') && pos('curveNavSlot')<pos('curveFixture'),kind+' sequence');
  assert.equal((s.match(/id="upload"/g)||[]).length,1,kind+' single original upload input');
  assert(s.includes('id="upload" type="file" accept="image/*" multiple'),kind+' bulk image upload stays');
  assert.equal((s.match(/class="cv-mini"/g)||[]).length,17,kind+' all 17 indicator charts retained');
}
for(const word of ['开赛/15/30/40提醒','进球','红牌'])assert(html.includes(word),'keep original notification descriptions');
console.log('PASS v4.5.1: upload below 17 charts, native image input unchanged, monitor and warnings still present');
