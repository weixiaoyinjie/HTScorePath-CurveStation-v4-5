package com.htlive.monitor;
import org.json.JSONArray;
import org.json.JSONObject;
public class MarketDataV44Test {
  private static void putStat(JSONArray list,String type,Object value){list.put(new JSONObject().put("type",type).put("value",value));}
  private static JSONObject team(int id,boolean extra){
    JSONArray stats=new JSONArray();
    putStat(stats,"Total Shots",extra?7:5);
    putStat(stats,"Shots on Goal",extra?3:1);
    putStat(stats,"Shots insidebox",extra?4:2);
    if(extra){putStat(stats,"Attacks",28);putStat(stats,"Dangerous Attacks",12);
      putStat(stats,"Key Passes",2);putStat(stats,"Crosses",5);putStat(stats,"Goalkeeper Saves",1);
      putStat(stats,"Total passes",182);putStat(stats,"Passes accurate",158);
      putStat(stats,"Passes %","86%");putStat(stats,"Expected Goals",0.71);}
    return new JSONObject().put("team",new JSONObject().put("id",id)).put("statistics",stats);
  }
  private static void check(boolean ok,String msg){if(!ok)throw new IllegalStateException(msg);}
  public static void main(String[] args)throws Exception{
    JSONObject data=MatchData.combine(new JSONArray().put(team(10,true)).put(team(20,false)),10,20);
    JSONObject h=data.optJSONObject("home"),a=data.optJSONObject("away");
    check(h.optInt("attacks")==28,"attack parsing");
    check(h.optInt("keyPasses")==2,"key passes");
    check(h.optInt("crosses")==5,"crosses");
    check(h.optInt("saves")==1,"saves");
    check(h.optInt("passes")==182,"passes");
    check(h.optInt("passPct")==86,"accurate %");
    check(a.opt("keyPasses")==JSONObject.NULL,"missing stays null");
    check(data.optBoolean("available"),"original coverage rule remains");
    System.out.println("PASS: v4.4 MatchData screenshot stats and null coverage");
  }
}
