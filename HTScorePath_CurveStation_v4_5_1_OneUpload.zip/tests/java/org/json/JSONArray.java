package org.json;
import java.util.ArrayList;
public class JSONArray {
  private final ArrayList<Object> a=new ArrayList<>();
  public JSONArray put(Object o){a.add(o);return this;}
  public int length(){return a.size();}
  public JSONObject optJSONObject(int i){return i>=0 && i<a.size()&&a.get(i) instanceof JSONObject?(JSONObject)a.get(i):null;}
  public String toString(){return a.toString();}
}
