const assert=require('node:assert/strict'),fs=require('node:fs');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const js=fs.readFileSync('app/src/main/assets/trend_dashboard.js','utf8');
const service=fs.readFileSync('app/src/main/java/com/htlive/monitor/MonitorService.java','utf8');
const original=fs.readFileSync('../HTScorePath_v4_4_work/app/src/main/java/com/htlive/monitor/MonitorService.java','utf8');
assert(html.indexOf('id="upload"')<html.indexOf('id="cvTimelineCard"')&&html.indexOf('id="cvTimelineCard"')<html.indexOf('id="cvXgCanvas"'));
const expectOrder=['xg','attacksDelta','dangerDelta','pos','shots','onDelta','cornersDelta','keyPassDelta','saves','passPct','crossesDelta','areas'];
for(let i=1;i<expectOrder.length;i++)assert(html.indexOf('data-series="'+expectOrder[i-1]+'"')<html.indexOf('data-series="'+expectOrder[i]+'"'),`ordering ${expectOrder[i]}`);
assert(html.indexOf('id="cvOptionalCharts"')>html.indexOf('id="cvAreaCanvas"'));
assert(html.includes('<details class="cv-deep cv-optional-charts"')&&!html.includes('<details open class="cv-deep cv-optional-charts"'));
for(const value of ['goal','red','yellow','var','sub','corner','shot','offside'])assert(js.includes(value),value);
assert(js.includes("observed=g.entries.every(e=>!e.exact)")&&js.includes("observed?'observed':'exact'"),'source distinction');
assert(js.includes('data-event-idx'),'interactive event details');
assert(service.includes('chartYellow')&&service.includes('chartSub'));
const vStart=service.indexOf('                        // Chart-only event types.');
const vEnd=service.indexOf('                                .put("teamId"',vStart);
const oStart=original.indexOf('                        if("Goal".equalsIgnoreCase(type)');
const oEnd=original.indexOf('                                .put("teamId"',oStart);
assert(vStart>=0&&vEnd>vStart&&oStart>=0&&oEnd>oStart);
assert.equal(service.slice(0,vStart)+original.slice(oStart,oEnd)+service.slice(vEnd),original,'only chart-event capture code changes');
for(const f of ['AlertNotifier.java','AlertPolicy.java','ReminderReceiver.java','ScoreGuardEngine.java','GoalWarningEngine.java']){
 const path='app/src/main/java/com/htlive/monitor/'+f;
 assert.equal(fs.readFileSync(path,'utf8'),fs.readFileSync('../HTScorePath_v4_4_work/'+path,'utf8'),f);
}
console.log('PASS v4.5: horizontal timeline first, screenshot order, actual/observed source, notifications untouched');
