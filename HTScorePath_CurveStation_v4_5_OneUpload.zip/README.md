# HT SCORE PATH CurveStation v4.5 · 足球合约化时间曲线终端

这份源码是从 v4.3 Compact 的完整工程增量升级，而非重新制作原版。

## v4.5 新增和保留

- **首页上传按钮优先**：小型上传比赛图片按钮仍在首页最顶部，OCR、按 Fixture ID 自动核对和添加到监控仍用原功能。
- **首页同时显示 17 张紧凑曲线 + 事件时间轴**，向下滑动。主队红、客队绿，同一横轴比赛分钟、独立纵轴指标值；单图放大、同步点击十字光标、3/5/10 分钟窗口仍可操作。完整页面顺序：xG累计、综合攻势动量研究指数、xG新增、射正新增、禁区内射门新增、危险进攻新增、进攻次数新增、射门新增、原版累计总射门、角球新增、关键传球新增、控球率、传球准确率、门将扑救、传中新增、传球新增、三区行动位置占比（待位置数据源）以及事件时间轴。
- **第一张截图统计加入解析**：新增 `attacks` 进攻次数、`keyPasses` 关键传球、`crosses` 传中、`saves` 门将扑救、`passes` 传球数、`accuratePasses` 成功传球、`passPct` 成功率，保留已有 xG、危险进攻、控球、角球与射门族指标。
- **第二张截图时间线**：复用原请求的 `/fixtures/events` 信息记录真实分钟的进球/红牌/VAR，角球只在统计发生增长的采样分钟标注，不伪装为准确发生时刻。部分比赛事件源可能缺失。
- **攻势动量图**：使用实际观察到的 xG、射正、禁区射门、总射门、危险进攻、进攻次数 3/5/10 分钟增量进行归一化叠加，是尚未历史验证的描述性指数，**不是胜率、进球概率、CVD 或 OI**。没有至少 2 项且权重足量的同阶段窗口数据时显示缺失，不给出虚假的信号。
- **位置区域比例**：第一张截图的行动区域 3 区百分比无法由该 API 的控球率直接推出；保留带数据来源标注的图区，后续如接入独立事件位置提供商且提供真实值才绘制，目前无数据提示。
- **老界面/老预警保持**：原有 2/3 张主单保险单、开赛/15/30/40提醒、进球红牌、守分、图片 OCR、API 设置、AI 手动分析、人工记录赔率和结算价继续保留在独立页面/主图下方。原 `AlertPolicy.java`、`AlertNotifier.java`、`ReminderReceiver.java`、`ScoreGuardEngine.java` 等通知核心文件没有改动。`MonitorService.java` 仅加只读的曲线时间轴字段；未改变推送规则，也不因曲线额外请求 API。
- **采样与质量保障**：每场上半场采用真实 API 响应周期的采样，保留本机历史；API 缺失不填零，统计重置不计算负增量，进球红牌不同阶段不跨窗口。没有开始采集前的历史不能凭空补齐。

## 上传 GitHub 自动编译（源码 ZIP + workflow）

1. 新建一个 GitHub 仓库。
2. 根目录上传 `HTScorePath_CurveStation_v4_4_OneUpload.zip`（保持压缩包原样）。
3. 在仓库创建 `.github/workflows/build-apk.yml`，内容直接复制单独提供的 `HTScorePath_CurveStation_v4_4_build-apk.yml`。如果仓库已解压上传工程，则要从 workflow 删除 Unpack source ZIP 步骤。
4. Actions → Build HT ScorePath CurveStation v4.5 APK → Run workflow，成功后在 Artifacts 下载 `HTScorePathCurveStation-v4_4-debug-apk`。
5. 安装新 APK，在「接口设置」录入自己的 API-FOOTBALL Key；可以选择性录入 AI Key。**不要把 Key 提交 GitHub 仓库。**

## 交互预览

打开单独提供的 `HTScorePath_v4_4_完整指标交互预览.html`，包含同一份页面 JS 和**明确标注的模拟数据**，可纵向滑动、放大、切换 3/5/10 分钟、切换其他页面；网页版没有真实的后台监控、OCR 和 Android 通知。

## 实际测试与边界

- Node 测试已覆盖：原 UI/导入/比分单规则、历史曲线、阶段中断、缺失值、合成动量、截图新增字段与事件 UI；Java 桌面测试验证额外统计解析和 null 处理。
- Chromium 移动视口交互验证已通过：可绘制 17 张图，能切换放大、窗口、设置页，无前端 JavaScript 异常。
- 本环境没有可用的 Android SDK/Gradle 编译环境；**没有生成或实测 v4.5 APK**。请通过 GitHub Actions 构建并验证后台通知、API 配额和不同机型兼容性。
- 运动数据存在服务商延迟、覆盖不完整和采样误差，不应仅用交叉、单次短窗波动或复合指数作为入场依据；不自动登录投注平台、下注或提前结算。

---

## 前一版本功能与设计备注（供参考）

# HT SCORE PATH v4.3 · 紧凑多指标行情主页

**本轮只改变曲线主页结构和图表布局；原有预警通知、OCR、足球 API、AI、比分单控制器没有更改。**

- 首页顶部只有上传比赛图片按钮，直接下接六张可滚动双队红绿曲线。
- 每张默认图表高度 112 CSS px，缩短标题/轴标签/内边距；单图可点「放大」切换 203px，仍可点击同步定位分钟。
- 旧版原位于曲线前方的标题、导航、选择比赛、演示入口、时间窗口、识别详情、状态和说明，均移到全部六张曲线之后；切换其他页面时导航恢复正常位置。
- 缺失指标显示无数据，不填 0；假数据仅用于明确标注的演示，不属于实时分析。

# HT SCORE PATH CurveStation v4.2 — 多指标纵向行情主页

此工程是从用户提供的 `HTScorePathGuard_OneUpload.zip` 实际源码增量开发的**独立 Android App**。新安装包 ID `com.htlive.monitor.scorepathcharts`，不会覆盖原版 `com.htlive.monitor.scorepathguard`。


## v4.2 主屏多图纵向滚动（本轮改版）

- 图片上传始终在主页顶部，仍调用旧 `upload` 和 OCR/API 匹配流程，只有一个文件上传控件。
- 主页直接纵向展示六张可上下滑动曲线：①累计xG ②最近3/5/10分钟xG新增 ③同期射正新增 ④同期禁区内射门新增 ⑤累计总射门 ⑥同期危险进攻新增（仅在接口提供时显示）。
- 统一主队红色、客队绿色；全部横轴为比赛分钟，纵轴是各自指标的数值；点击任意图，六图同步显示相同采样时刻十字定位。
- 三档短窗可以一键切换；高级单指标选择、双指标叠加和详细 AI 分析折叠在六图之后；原版监控、图片识别详情、价格记录、预警、API 设置继续在独立 Tab，不修改通知逻辑。
- 不向监控线程追加 HTTP 请求；仍由保存的原始 API 快照绘图；缺失xG/危险进攻不插值、不用0替代；进球/红牌分段不连接。模拟预览明确标注不可作为实际比赛数据。

**网页预览**：`HTScorePath_v4_2_多指标滚动交互预览.html` 是打包后的独立离线演示，页面代码来自 Android 项目同一份 `index.html` 和 JS 资源，浏览器自动进入模拟比赛以展示多图；不连接真实比赛。

## 已实现的功能

1. **完整保留 v3 原有监控、通知及截图识别**：筛选截图本地 OCR，核对 Fixture ID，逐场主单/保险单 2/3 张设置，开赛/15/30/40 分钟固定提醒、进球/红牌/守分与人工结算核查、自动预约、预警记录、后台监控、原有 AI 风险复核。`AlertNotifier.java`、`ReminderReceiver.java`、`AlertPolicy.java`、`ScoreGuardEngine.java` 原代码未动。
2. **默认进入「走势曲线」主页**，原四个入口和操作不变。每场选择即可查看上半场真实采样的累计指标、最近 3/5/10 分钟增长、主客对比、两阶段加速/减速、多指标归一化叠加（明确不是概率）、时间轴进球/红牌标记，数据来源和样本覆盖提示。点击曲线可看相应分钟与指标值。
3. **严格区分原预警短窗和曲线长档案**：`MonitorService` 只额外将**同一 API 请求已经取得的快照**写入 `TrendSeriesStore` 的私有文件，不会因为图表增加 API 请求。保留至多 180 个采样点/比赛；上半场完结时保留档案，手动删除才清理。保存上半场有效统计、主客比分、实际查询时刻、进球和红牌事件与结构阶段。
4. **数据质量保护**：缺失 JSON `null` 不等于 0；短窗指标必须具备当前和接近指定窗口前的真实采样；不能用进球前统计作为进球后新增；统计回拨不转成新增；红牌/进球阶段截断；API 没有 xG 或危险进攻则不产生假曲线。采样时间仅代表本机收到接口数据的时间，*不保证供应商实际更新时刻*。
5. **人工价格轨迹**：按主单/保险1/保险2，逐次人工输入当时的赔率/真实提前结算报价/本金及对应分钟。数据留在私有文件，价格曲线只画真实人工记录，没有缺失分钟的推断价。原 App 不接触投注平台，不能自动下注或结算。
6. **手动 AI 曲线复核**：点击按钮后，若已填 AI Key，则只发送最后 50 个上半场采样的比分、事件阶段与非财务指标，不发送资金、下注截图、赔率或 Cash Out 报价。AI 输出走势方向、数据证据、风险与 C/PASS 研究评级；**不会更改原有预警、自动给下注建议或触发结算**。
7. **模拟界面按钮**：展示视觉效果，必须在界面上注明模拟；不存入真实档案，也不能作为投注证据。

## 关键代码

- `app/src/main/assets/index.html`：保留原 UI，增加曲线与价格页。
- `app/src/main/assets/trend_engine.js`：纯 JavaScript 走势指标、滚动增量、结构阶段断点和证据一致性。
- `app/src/main/assets/trend_dashboard.js`：Android WebView Canvas 交互式曲线、报价记录和 AI 分析显示。
- `app/src/main/java/com/htlive/monitor/TrendSeriesStore.java`：私有的持久化曲线与人工报价档案。
- `app/src/main/java/com/htlive/monitor/TrendAiReview.java`：可选曲线 AI 读取。
- `MainActivity.java`：仅添加曲线读取、报价写入及人工 AI 复核桥接。
- `MonitorService.java`：**仅增加一次记录曲线档案的调用**，原报警规则未变。

## Android APK 编译（推荐 GitHub Actions）

1. 到 https://github.com/new 创建新 **Private** 仓库，建议仓库名 `HTScorePath-CurveStation-v4`。
2. 在仓库**根目录**上传 `HTScorePath_CurveStation_v4_2_OneUpload.zip`（保持 ZIP 原样，不需要先解压）。
3. 在 GitHub 网页创建 `.github/workflows/build-apk.yml`，完整粘贴提供的 `HTScorePath_CurveStation_v4_2_build-apk.yml`。
4. 到 **Actions → Build HT ScorePath CurveStation v4 APK → Run workflow**；成功后下载工件 `HTScorePathCurveStation-v4-debug-apk`，其中有 Android `app-debug.apk`。
5. 安装 APK、允许通知和后台运行，在 App「接口设置」填写自己的 API-FOOTBALL Key（必需），OpenAI Key 可选。请勿在 GitHub 中写入 Key。

如果直接解压上传所有文件而不是上传 ZIP，需要删除工作流中 `Unpack source ZIP` 这一步，以免找不到压缩包。

## 可复现测试

在工程根目录：

```bash
for t in tests/*.test.js; do node "$t"; done
```

Java 逻辑测试（和 v3 保持相同方式）：

```bash
mkdir -p /tmp/ht-guard-test
javac -encoding UTF-8 -d /tmp/ht-guard-test \
  app/src/main/java/com/htlive/monitor/AlertPolicy.java \
  tests/java/com/htlive/monitor/AlertPolicyTest.java
java -cp /tmp/ht-guard-test com.htlive.monitor.AlertPolicyTest
javac -encoding UTF-8 -d /tmp/ht-guard-test \
  tests/java/org/json/JSONObject.java tests/java/org/json/JSONArray.java \
  app/src/main/java/com/htlive/monitor/MainScoreRiskEngine.java \
  app/src/main/java/com/htlive/monitor/ScoreGuardEngine.java \
  tests/java/com/htlive/monitor/MainScoreRiskEngineTest.java \
  tests/java/com/htlive/monitor/ScoreGuardEngineTest.java \
  tests/java/com/htlive/monitor/ScorePathTest.java
for c in MainScoreRiskEngineTest ScoreGuardEngineTest ScorePathTest; do \
  java -cp /tmp/ht-guard-test com.htlive.monitor.$c; done
```

**编译状态**：此运行环境未配置 Android SDK / Gradle，因此不能将上传的原版 `app-debug.apk` 伪装成 v4 的新 APK。本次交付是完整可上传源码 ZIP 与 GitHub Actions 构建流程；已在 Chromium 检查新增 Canvas 页渲染，并运行 Node / Java 逻辑测试。真正 Android APK 构建、后台通知延迟及不同手机兼容性尚待 GitHub CI 和设备实测。

## 限制与原则

- API-FOOTBALL 不保证每场实时 xG、危险进攻或某些联赛的上半场统计；没有数据就提示不足。
- 本版是**手机客户端前台服务采样**，并非云服务器 24h 持续采样。Android 后台、电池、网络、接口额度会影响采样和通知。曲线开始于监控实际启动时间，不能自动还原此前未采集的比赛分钟。
- 同一足球 API 的各项指标不是独立事实验证。AI 对采样做解释，不应代替客观测试和价格核查。
- 所有市场报价由用户手动输入，不能保证 Cash Out 报价仍有效。不自动下注、不代为决策。


## v4.5 新首页：Bet365统计曲线 + 横向事件时间轴

顶部导入图片入口之后，立即是主队红色/客队绿色的横向事件时间轴。按照赛事分钟从左到右依次放置 API精确事件（进球、红黄牌、VAR、换人）和仅从相邻 API统计快照发现的事件（角球、射正、越位）。采样发现只标注“观察分钟”，并不冒充真正事件发生时刻。为避免拥挤，按4分钟密集事件聚合；点击查看组内每条事件的原始时间与来源；图上仍保留真实采样分钟与短窗增量，不自动推荐下注。

紧接着为截图统计 12 张主客双线紧凑曲线：xG、进攻、危险进攻、控球率、总射门、射正、角球、关键传球、门将扑救、传球准确率、传中、三区行动区域。xG、进攻等不是每场都具备；三区区域占比在没有位置数据时明确显示缺失。扩展研究指标放在默认折叠区。原有监控页、赔率复盘、AI、比分单、OCR识别、通知引擎均保留。
