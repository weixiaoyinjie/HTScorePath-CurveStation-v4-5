const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const parserJs=fs.readFileSync('app/src/main/assets/import_parser.js','utf8');
const extract=(start,end)=>{let i=html.indexOf(start),j=html.indexOf(end,i+start.length);assert(i>=0&&j>i,`missing ${start} to ${end}`);return html.slice(i,j)};
const normal={id:'1581567',home:'Shirak',away:'Gandzasar',league:'Armenia',kickoff:'2026-11-20T15:00:00+00:00'};
const sample='2026-11-20 12:00 开赛\nShirak vs Gandzasar\nFixture ID: 1581567';
const state={};
vm.runInNewContext(parserJs,state);
assert.equal(state.HTImportParser.parse({ocrText:sample,ocrEdited:true}).items[0].fixtureId,'1581567');
assert.equal(state.HTImportParser.match(state.HTImportParser.parse({ocrText:sample,ocrEdited:true}),[normal]).matched.length,1);
const box={textContent:''};const statusContext={photos:[],isRunning:false,autoArmed:false,$:(id)=>id==='homeImportStatus'?box:null};
vm.runInNewContext(extract('function updateHomeError(message)','function setup()'),statusContext);
statusContext.updateHomeImportStatus();assert(box.textContent.includes('上传后自动识别'));
const statusPhoto={id:'p',ocrPending:true,importedIds:[],unmatched:[]};statusContext.photos=[statusPhoto];
statusContext.updateHomeImportStatus();assert(box.textContent.includes('正在识别'));
statusPhoto.ocrPending=false;statusPhoto.importStage='verify';statusContext.updateHomeImportStatus();assert(box.textContent.includes('API-FOOTBALL'));
statusPhoto.importStage='review';statusPhoto.unmatched=['比赛ID核验失败'];statusContext.updateHomeImportStatus();assert(box.textContent.includes('比赛ID核验失败'));
statusPhoto.importedIds=['1581567'];statusContext.updateHomeImportStatus();assert(box.textContent.includes('已加入 1 场'));

const photo={id:'p',ocrText:sample,ocrEdited:true,ocrPending:false,importedIds:[],unmatched:[],ocrError:'',importStage:'ocr'};
let renders=0,stores=0,callPaths=[];
const ctx={
 HTImportParser:state.HTImportParser,photos:[photo],watch:[],fixtures:[],screenshotFixtures:[],isRunning:false,apiKey:'test-key',
 $:(id)=>({value:id==='key'?'test-key':''}),renderPhotos:()=>{renders++},store:()=>{stores++;return true},
 entry:f=>({id:String(f.fixture.id),home:f.teams.home.name,away:f.teams.away.name,league:f.league.name,kickoff:f.fixture.date}),
 async api(path){callPaths.push(path);return{response:[{fixture:{id:1581567,date:'2026-11-20T15:00:00+00:00'},teams:{home:{name:'Shirak'},away:{name:'Gandzasar'}},league:{name:'Armenia'}}]}},
 applyWatchlist(next){ctx.watch=next;return true},armAutoWatch:()=>{},
 loadScreenshotFixtures:()=>{throw Error('Must not load entire date for ID-containing screenshots')}
};
vm.runInNewContext(extract('function fixtureCandidates()','async function loadScreenshotFixtures'),ctx);
vm.runInNewContext('const verifiedFixtureIds=new Set();'+extract('async function verifyPhotoAndImport(p)','function armAutoWatch()'),ctx);
(async()=>{
 await ctx.verifyPhotoAndImport(photo);
 assert.deepEqual(callPaths,['fixtures?id=1581567']);
 assert.equal(ctx.watch.length,1,'verified screenshot adds real fixture');
 assert.equal(photo.importStage,'success');
 assert.equal(photo.importedIds[0],'1581567');
 assert(renders>2&&stores>2,'UI refreshed and persisted');
 // Invalid kickoff: zero matched must still persist failure detail (the old bug).
 const mismatch={id:'p2',ocrText:sample.replace('12:00','10:00'),ocrEdited:true,ocrPending:false,importedIds:[],unmatched:[],ocrError:'',importStage:'ocr'};
 ctx.photos=[mismatch]; ctx.watch=[];renders=0;stores=0;
 await ctx.verifyPhotoAndImport(mismatch);
 assert.equal(ctx.watch.length,0,'do not auto-add wrong kickoff');
 assert.equal(mismatch.importStage,'review');
 assert(mismatch.unmatched.length>0,'explain why fixture ID + date/time mismatch');
 assert(renders>0&&stores>0,'failed matching still updates screen and storage');
 assert(html.includes("updateHomeImportStatus();\n}"),'photo rendering always refreshes home status');
 assert(html.includes("reader.readAsDataURL(file)"),'Android FileReader backed import');
 assert(html.includes('OCR识别超时'),'OCR fail safe');
 console.log('PASS v4.5.2: Shirak real Fixture ID, successful import, wrong-time rejection, failure UI saved and refreshed, OCR timeout');
})().catch(e=>{console.error(e);process.exit(1)});
